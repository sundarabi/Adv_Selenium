package generic_utility;

public interface Paths {

	String filepath="./src/test/resources/vtiger.properties";
	String excelpath="./src/test/resources/data_fetch.xlsx";
}
	

